#ifndef _fila_int_h
#define _fila_int_h

void cria_fila();
int enfileira(int y);
int desenfileira(int *y);
int fila_vazia();
int fila_cheia();
void imprime_fila();
void libera_fila();
void cabecalho(void);

#endif
